#include <stdio.h>
#include <string.h>
#define MAX_SIZE 100
void bitStuffing(char input[], char output[]) {
    int i, j = 0, count = 0;
    int length = strlen(input);
    for (i = 0; i < length; i++) {
        output[j] = input[i];
        j++;
        if (input[i] == '1') {
            count++;
        } else {
            count = 0;
        }
        if (count == 5) {
            output[j] = '0';
            j++;
            count = 0;
        }
    }
    output[j] = '\0';
}

int main() {
    char input[MAX_SIZE], output[MAX_SIZE];
    printf("Enter the input bit string: ");
    scanf("%s", input);
    bitStuffing(input, output);
    printf("Bit-stuffed output: %s\n", output);
    return 0;
}
