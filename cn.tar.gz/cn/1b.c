#include <stdio.h>
#include <string.h>
#define MAX_SIZE 100
void charStuffing(char input[], char output[])
 {
    int i, j = 0;
    int length = strlen(input);
    char flag = 'F'; 
    char escape = 'E';
    output[j++] = flag;
    for (i = 0; i < length; i++) {
        if (input[i] == flag || input[i] == escape) {
            output[j++] = escape;
        }
        output[j++] = input[i];
    }
    output[j++] = flag;
    output[j] = '\0';
}
int main() {
    char input[MAX_SIZE], output[MAX_SIZE];
    printf("Enter the input character string: ");
    scanf("%s", input);
    charStuffing(input, output);
    printf("Character-stuffed output: %s\n", output);
    return 0;
}

