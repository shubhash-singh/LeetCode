#include <stdio.h>
#include <stdbool.h>
#define WINDOW_SIZE 4
#define FRAME_COUNT 8
// Data structure for frames
typedef struct {
    int sequence_number;
    bool is_acknowledged;
    char data;
} Frame;

void sender(Frame frames[], int total_frames) {
    int base = 0;
    int next_seq = 0;

    while (base < total_frames) {
        for (int i = base; i < base + WINDOW_SIZE && i < total_frames; i++) {
            if (!frames[i].is_acknowledged) {
                printf("Sending frame %d: %c\n", frames[i].sequence_number, frames[i].data);
            }
        }

        int ack;
        printf("Enter the last acknowledged frame number (or -1 to exit): ");
        scanf("%d", &ack);

        if (ack == -1) {
            break;
        }
        for (int i = base; i <= ack; i++) {
            frames[i].is_acknowledged = true;
        }
        while (base < total_frames && frames[base].is_acknowledged) {
            base++;
        }
    }
}

void receiver(Frame frames[], int total_frames) {
    for (int i = 0; i < total_frames; i++) {
        printf("Received frame %d: %c\n", frames[i].sequence_number, frames[i].data);
    }
}

int main() {
    Frame frames[FRAME_COUNT];
    for (int i = 0; i < FRAME_COUNT; i++) {
        frames[i].sequence_number = i;
        frames[i].is_acknowledged = false;
        frames[i].data = 'A' + i;
    }

    printf("Sender:\n");
    sender(frames, FRAME_COUNT);

    printf("\nReceiver:\n");
    receiver(frames, FRAME_COUNT);

    return 0;
}
