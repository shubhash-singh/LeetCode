#include"stdio.h"

int main() {
    int i = 0, j = 0, nei, n, ah[20];
    int v[50][50], r[20], min = 10000, si;
    char s[50], dest, line[50];
    for (i = 0; i < 50; i++) s[i] = '\0';
    printf("\nEnter the no of nodes:\n");
    scanf("%d", & n);
    printf("\nEnter the destination:\n");
    scanf("%s", & dest);
    printf("\nEnter the no.of neighbours:\n");
    scanf("%d", & nei);
    printf("\nEnter the neighbours & slash(0) at end:\n");
    for (i = 0; i <= nei; i++) scanf("%s", &s[i]);
    for (j = 0; j < nei;) {
        printf("\nThe distance from %c to %c :", dest, s[j]);
        scanf("%d", & ah[j]);
        j++;
    }

    printf("\nEnter the table of entries:");
    for (i = 0; i < n; i++)
        for (j = 0; j < nei; j++)
            scanf("%d", & v[i][j]);
    for (i = 0; i < n; i++) {
        min = 10000;
        for (j = 0; j < nei; j++)
            if (v[i][j] + ah[j] < min) {
                min = v[i][j] + ah[j];
                line[i] = s[j];
            }
        r[i] = min;
        if (dest - 97 == i) {
            r[i] = 0;
            line[i] = ' ';
        }
    }
    printf("\n new estimated delays from %c    |", dest);
    printf("    Line\n____________________________  _________________\n\n");
    for (i = 0; i < n; i++) printf("\n\t %d \t\t\t| %c ", r[i], line[i]);
}
