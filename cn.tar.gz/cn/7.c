#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
    int i,ch,lp;
    char cipher[50],plain[50];
    char key[50];
    while(1){
        printf("\n-----MENU-----");
        printf("\n1:Data Encryption\t2:Data Decryption\t3:Exit");
        printf("\nEnter your choice:");
        scanf("%d",&ch);
        switch(ch){
            case 1:	printf("\nData Encryption");
                printf("\nEnter the plain text:");
                fflush(stdin);
                scanf("%s", &plain);
                printf("\nEnter the encryption key:");
                scanf("%s", &key);
                lp=strlen(key);
                for(i=0;plain[i]!='\0';i++) cipher[i]=plain[i]^lp;
                cipher[i]='\0';
                printf("\nThe encrypted text is:");
                puts(cipher);
                break;
            case 2:	printf("\nData decryption");
                for(i=0;cipher[i]!='\0';i++) plain[i]=cipher[i]^lp;
                printf("\nDecrypted text is:");
                puts(plain);
                break;
            case 3:	exit(0);
        }
    }
}


